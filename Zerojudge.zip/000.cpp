#include <bits/stdc++.h>

#pragma GCC optimize("Ofast,unroll-loops,no-stack-protector,fast-math")

using namespace std;

#define fastio ios::sync_with_stdio(false), cin.tie(NULL)

typedef long long ll;

int FastPower(int a, int b, int m) {
	a %= m;
	int ans = 1;
	while(b) {
		if(b & 1)
			ans = ll(ans) * a % m;
		a = ll(a) * a % m;
		b >>= 1;
	}
	return ans;
}

bool solve(int n) {
	if(n <= 4)
		return n == 2 || n == 3;
	int N = n - 1, cnt = __builtin_ctz(N), m = N >> cnt;
	int a[3] = {2, 7, 61};
	for(int i=0;i<3;i++) {
		if(n == a[i])
			return true;
		int temp = FastPower(a[i], m, n);
		if(temp == 1 || temp == n - 1)
			continue;
		for(int t = 0; t < cnt; ++t) {
			temp = ll(temp) * temp % n;
			if(temp == 1)
				return false;
			if(temp == n - 1)
				break;
		}
		if(temp != n - 1)
			return false;
	}
	return true;
}

int main() {
	fastio;
	int n;
	while(cin >> n)
		cout << ((solve(n)) ? "���" : "�D���") << "\n";
	return 0;
}

