#include <bits/stdc++.h>
using namespace std;

int main(){
	int c;
	cin >> c;
	int T = 1;
	while (T<=c){
		int s,K;
		cin >> s >> K;
		string S;
		cin >> S;
		int k = 0;
		int ans = 0;
		for (int i=0;i<s/2;i++){
			if (S[i]!=S[s-(i+1)]){ //0,4 1,3 2,2
				k++;
			}
		}
		if (k == K){
			ans = 0;
		}
		else if (k < K){
			ans = K-k;
		}
		else {
			ans = k - K;
		}
		cout << "Case #" << T << ": " << ans << endl;
		T++;
	}
}

