#include <bits/stdc++.h>
using namespace std;
int T = 1;
void solve(int L, string s){
	int ans = 1;
	cout << "Case #" << T << ": ";
	for(int i=0;i<L;i++){
		ans = 1;
		for (int j=i;j>0;j--){
			if (i==0){
				cout << ans << " ";
				continue;
			}
			else {
				if (s[j]>s[j-1]){
					//cout << "A";
					ans++;
				}
				else {
					//cout << "B";					
					break;
				}
			}
		}
		cout << ans << " ";
	}
	cout << endl;
}

int main(){
	int c;
	cin >> c;
	while (T<=c){
		int L;
		cin >> L;
		string s;
		cin >> s;
		solve(L,s); 
		T++;
	}
}

