#include <bits/stdc++.h>
using namespace std;
int T=1;

void solve(int n, vector<int> a){
	int d = 0;
	int Max = 0;
	bool diff = false;
	vector<int> re;
	re.push_back(0);
	for(int i=0;i<n-1;i++){
		//cout << a[i] << endl;
		if(i==0){
			d = a[i] - a[i+1];
		}
		else {
			if (a[i]-a[i+1]!=d && a[i]-a[i-1]!=(-d)){
				diff = true;
				re.push_back(i);
			}
		}
	}
	if (diff==true){
		for(int i=2;i<re.size();i++){
			//cout << re[i]-re[i-1] << endl;
		Max = max(Max,(re[i]-re[i-2]));
		}
		cout << "Case #" << T << ": " << Max << endl;
	} 
	else {
		cout << "Case #" << T << ": " << n << endl;
	}
}

int main(){
	int c;
	cin >> c;
	while(T<=c){
		int n;
		cin >> n;
		vector<int> a;
		for(int i=0;i<n;i++){
		int num;
		cin >> num;
		a.push_back(num);
		}
		solve(n,a);
		T++;
	}
}

