#include <bits/stdc++.h>
using namespace std;
int T=1;
void solve(){
	unsigned long long a;
	cin >> a;
	bool p = true;
	unsigned long long ans = 0;
	vector<unsigned long long> prime;
	if (a < 15){
		ans = 6;
	}
	else if (a < 35){
		ans = 15;
	}
	else if (a < 77){
		ans = 35;
	}
	else {
	prime.push_back(2);
	prime.push_back(3);
	prime.push_back(5);
	for (int i=7,gap = 4;i<=a;i=i+gap,gap=6-gap){
		for (int j=2;j<i;j++){
			if (i%j==0){
				p = false;
				break;
			}
		}
		if (p==true){
			if ((prime.back())*i<=a){
				ans = i*prime.back();
				prime.push_back(i);	
			}
			else{
			break;
			}
		}
		p = true;
	}
	}
	cout << "Case #" << T << ": ";
	cout << ans << endl;
}
int main(){
	int c;
	cin >> c;
	while(T<=c){
		solve();
		T++;
	}
}

