#include <bits/stdc++.h>
using namespace std;

int f(int);

int main(){
	int n,m;
	while (cin >> n >> m){
		int a = 1,b = 1,c = 1;
		for (int i=n;i>0;i--){
			a *= i;
		}
		for (int i=m;i>0;i--){
			b *= i;
		}
		for (int i=n-m;i>0;i--){
			c *= i;
		}
		cout << a/(b*c) << endl;
	}
}


