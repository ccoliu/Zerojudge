#include <bits/stdc++.h>
using namespace std;



int main(){
	string s;
	string suffix[] = {"a","e","i","y","o","ou","w"};
	while(cin >> s){
		if (s=="END") break;
		for (int i=0;i<s.length();i++){
			if (s[i]=='-'){
				if (s[i-2]+s[i-1]=='ou')
			}
		}
	}
}

