#include <stdio.h>
#include <stdlib.h>

int main(){
	char s[3] = {'b','a','d'};
	printf("%s\n",s);
}
