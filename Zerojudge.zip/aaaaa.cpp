#include <bits/stdc++.h>
using namespace std;
int T=1;
int main(){
	bool p = true;
	unsigned long long int c;
	cin >> c;
	cout << 2 << endl;
	cout << 3 << endl;
	cout << 5 << endl;
	for (int i=7,gap = 4;i<=sqrt(c);i=i+gap,gap=6-gap){
		for (int j=2;j<i;j++){
			if (i%j==0){
				p = false;
				break;
			}
		}
		if (p==true){
			cout << i << endl;
		}
		p = true;
	}
}

