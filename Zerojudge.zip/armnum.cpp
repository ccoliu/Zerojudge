#include <bits/stdc++.h>
using namespace std;

int main(){
	 int T=100;
	 vector<int> armnum;
	 while(T<=999){
	 	int n1,n2,n3;
	 	n1 = T/100;
	 	n2 = (T%100)/10;
	 	n3 = T%10;
	 	if (n1*n1*n1+n2*n2*n2+n3*n3*n3==T){
	 		armnum.push_back(T);
		 }
		 T++;
	 } 
	 for(auto i:armnum){
	 	cout << i << endl;
	 }
}

