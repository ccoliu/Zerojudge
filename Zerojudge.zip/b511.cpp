#include <bits/stdc++.h>
#include <vector>
using namespace std;

int N;
int currency[5] = {};
int num;
int money[5] = {};
bool re = false;

void recursive(int N,int money[5],int k,int j){
	cout << k << endl;
	if (re==true){
		int clone = k;
		for(int p=N-1;p>=0;p--){
			money[p] = clone/currency[p];
			clone -= money[p]*currency[p];
		}
		re = false;
	}
	if (k>num){
		money[j]--;
		return;
	}
	else if (k==num){
		int i = 0;
		cout << "(";
		for(i;i<N-1;i++){
			cout << money[i] << ",";
		}
		cout << money[i] << ")" << endl;
		re = true;
		return;
	}
	while(j>=0){
		money[j]++;
		recursive(N,money,k+currency[j],j);
		j--;
	}
}

int main(){	
	cin >> N;
	int j = N-1;
	for(int i=0;i<N;i++){
		int m;
		cin >> m;
		currency[i] = m; 
	}
	cin >> num;
	recursive(N,money,0,j);
}

