#include <bits/stdc++.h>
using namespace std;

int main(){
	int c;
	int N;
	cin >> c;
	while(N!=c){
		int h1,m1,h2,m2,time;
		bool in_time = true;
		cin >> h1 >> m1 >> h2 >> m2 >> time;
		m1 += time;
		if (m1>=60){
			h1 += m1/60;
			m1 %= 60;
		}
		if(h1>h2){
			in_time = false;
		}
		else if (h1==h2){
			if(m1>m2){
				in_time = false;
			}
		}
		if (in_time)
		cout << "Yes" << endl;
		else
		cout << "No" << endl;
		N++;
	}
}
