#include <bits/stdc++.h>
using namespace std;

int main(){
	int x1,x2,y1,y2;
	cin >> x1 >> y1 >> x2 >> y2;
	int a,b,c,d = 0;
	int gcd1,gcd2,gcd3 = 1;
	a = pow((x2-x1),2);
	b = y2-y1;
	c = 2 * x1 * (y1-y2);
	d = (y2-y1)*pow(x1,2) + pow((x2-x1),2)*y1;
	gcd1 = __gcd(a,b); gcd2 = __gcd(b,c); gcd3 = __gcd(c,d);
	gcd1 = __gcd(gcd1,gcd2); gcd2 = __gcd(gcd2,gcd3);
	gcd1 = __gcd(gcd1,gcd2);
	if(gcd1>=1) {
	a /= gcd1; b /= gcd1; c/=gcd1; d/=gcd1;
	}
	cout << a << "y = " << b << "x^2 + " << c << "x + " << d << endl;
} 
