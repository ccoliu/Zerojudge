#include <bits/stdc++.h>
using namespace std;

int main(){
	double R;
	cin >> R;
	cout << (R*9)/5 + 32 << endl;
}
