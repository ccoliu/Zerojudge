#include <bits/stdc++.h>
using namespace std;

int main(){
	vector<char> x;
	string a;
	cin >> a;
	int T = 0;
	for(int j=0;j<=1;j++){
	for(int i=0;i<a.length();i++){
		x.push_back(a[i]);
	}
	}
	char temp;
	for(int i=0;i<a.length();i++){
		T = 0;
		int j = i;
		while(T<a.length()){
			cout << x[j];
			j++;
			T++;
		}
		cout << endl;
	}
}
