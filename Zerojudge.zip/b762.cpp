#include <bits/stdc++.h>
using namespace std;

int main (){
	int N;
	cin >> N;
	int T = 0;
	int k = 0;
	int d = 0;
	int a = 0;
	int k_row = 0;
	while (T<N)
	{
		string c;
		cin >> c;
		if (c == "Get_Kill"){
			k++;
			k_row++;
			if (k_row>2){
				if (k_row>=8){
					cout << "LEGENDARY!" << endl;
				}
				switch(k_row){
					case 7:
						cout << "GUALIKE!" << endl;
						break;
					case 6:
						cout << "DOMINATING!" << endl;
						break;
					case 5:
						cout << "UNSTOPPABLE!" << endl;
						break;
					case 4:
						cout << "RAMPAGE~" << endl;
						break;
					case 3:
						cout << "KILLING SPREE!" << endl;
						break;
				}
			}
			else {
				cout << "You have slain an enemie." << endl;
			}
		}
		else if (c == "Get_Assist"){
			a++;
		}
		else if (c == "Die") {
			d++;
			if (k_row>2){
				cout << "SHUTDOWN." << endl;
			}
			else {
				cout << "You have been slained." << endl;
			}
			k_row = 0;
		}
		T++;
	}
	cout << k << "/" << d << "/" << a << endl;
}
