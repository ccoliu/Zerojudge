#include <bits/stdc++.h>
using namespace std;

int sum = 0;
void recursive(unsigned long long n,unsigned long long m,unsigned long long j){
	sum += j;
	cout << sum << endl;
	if (sum==n||m==0){
		cout << "Go Kevin!!" << endl;
		sum = 0;
		return;
	}
	else if (sum > n){
		cout << "No Stop!!" << endl;
		sum = 0;
		return;
	}
	else {
		recursive (n,m,j+m); 
	}
}

int main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
	unsigned long long r,T;
	while(cin >> r >> T){
	unsigned long long m = 1;
	recursive(r,T,m);
}
}
