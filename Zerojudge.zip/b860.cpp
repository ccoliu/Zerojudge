#include <bits/stdc++.h>
using namespace std;

int main () {
	int c,d;
	cin >> c >> d;
	int y = 0;
	int ava = 0;
	bool over = false;
	while (true){
	if (c >= 12){
		ava += c/12;
		y += c/12;
		c %= 12;
		c += ava;
	}
	if (ava > d){
		over = true;
		break;
	}
	else {
		d -= ava;
	}
	if ((d+y+c)>=12){
		if(y+c>=12){
			c += y;
			y = 0;	
		}
		else {
			y = 0;
			c = 12;
			d -= (12-c-y);
		}
		if (d==0){
			break;
		}
	} else 
		break; 
	}
	if (over==true){
		cout << d << endl;
	}
	else {
		cout << ava << endl;
	}
} 
