#include <bits/stdc++.h>
using namespace std;

int main(){
	string str;
	getline(cin,str);
	string h;
	getline(cin,h);
	vector<char> vec;
	string ans = "";
	for (int i=0;i<str.length();i++){
		if (str[i]==' '){
			str[i] = '1';
		}
	}
	for (int i=0;i<str.length();i++){
		vec.push_back(str[i]);
	}
	for (int i=0;i<vec.size();i++){
		if (str[i]=='1'){
			cout << h << ", " << ans << endl;
			ans = "";
		}
		else {
			ans += vec[i];
		}
	}
	cout << h << ", " << ans << endl; 
}
