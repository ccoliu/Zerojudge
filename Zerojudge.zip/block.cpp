#include <bits/stdc++.h>
using namespace std;

void travel(int,int);
int c= 0;
int block[100][100] = {0};
int w,h;
int main(){
	cin >> w >> h;
	block[h][w] = {0};
	for (int i=0;i<h;i++){
		for(int j=0;j<w;j++){
			cin >> block[i][j];
		}
	}
	int startx,starty;
	cin >> startx >> starty;
	travel(starty,startx);
	cout << c << endl;
}

void travel(int x,int y){
	if (block[x][y]==1){
		return;
	}
	block[x][y] = 1;
	c++;
	if (x-1>0){
		travel(x-1,y);
	}
	if (x+1<h){
		travel(x+1,y);
	}
	if (y-1>0){
		travel(x,y-1);
	}
	if (y+1<w){
		travel(x,y+1);
	}
	return;
}

