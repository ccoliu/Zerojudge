#include <bits/stdc++.h>
using namespace std;

int main(){
	int x;
	cin >> x;
	cout << x*0.3 << endl;
} 
