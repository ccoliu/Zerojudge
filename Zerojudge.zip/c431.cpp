#include <stdio.h>
#include <stdlib.h>
using namespace std;

int main(){
	int c;
	scanf("%d",&c);
	int b[101] = {};
	for(int i=0;i<c;i++){
		int input;
		scanf("%d",&input);
		b[input]++;
	}
	for(int i=1;i<=101;i++){
		for(int j=0;j<b[i];j++){
				printf("%d ",i);
		}
	}
	printf("\n");
}
