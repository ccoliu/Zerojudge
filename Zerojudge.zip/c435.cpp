#include <bits/stdc++.h>
using namespace std;

int main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
    int c;
    cin >> c;
    int T[100000] = {};
    int max_ans = 0;
    int Max = 0;
    for(int i=0;i<c;i++){
        int num;
        cin >> num;
        T[i] = num;
        Max = max(Max,T[i]);
        if (max_ans < Max-T[i]){
            max_ans = Max-T[i];
        }
    }
    cout << max_ans << endl;
}
