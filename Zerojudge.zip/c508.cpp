#include <bits/stdc++.h>
using namespace std;
int main(){
	int c;
	vector<int> box;
	scanf("%d",&c);
	for(int i=0;i<c;i++){
		int input;
		cin >> input;
		box.push_back(input); 
	}
	sort(box.begin(),box.end());
	for(int i=0;i<c;i++){
		cout << box[i] << " ";
	}
	cout << endl;
	for(int i=c-1;i>=0;i--){
		if (box[i]!=box[i+1]) {
			cout << box[i] << " ";
		} else continue;
	}
	cout << endl;
}
