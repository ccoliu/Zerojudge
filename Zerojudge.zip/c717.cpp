#include <bits/stdc++.h>
using namespace std;

int main(){
	string c;
	getline(cin,c);
	cout << c << " " << c << endl; 
}

