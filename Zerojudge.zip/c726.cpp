#include <bits/stdc++.h>
using namespace std;

int main(){
	string name1,name2;
	cin >> name1 >> name2;
	cout << name1 << " and " << name2 << " sitting in the tree" << endl;
}

