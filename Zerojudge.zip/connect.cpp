#include <bits/stdc++.h>
using namespace std;

void clear(int list[6][7]){
		
}



int main(){
while(true){
	int T=0;
	char list[6][7] = {' '}; //(y,x)
	int l[7] = {0};
	while(true){
		int line;
		cin >> line;
		if (line > 7 or line < 1){
			cout << "The line isn't exist, choose again:" << endl;
			continue;
		}
		if (l[line-1]>=6){
			cout << "The line is full, choose again:" << endl;
			continue;
		}
		if (T%2==0){
			list[line][l[line-1]] = 'y';
		} else 	list[line][l[line-1]] = 'r';
		l[line-1]++;
		T++;
		if(T>=7){
			bool win = false;
			int connect = 0;
			for(int j=0;j<=5;j++){ //x
				connect = 0;
				for(int i=0;i<=6;i++){
					if (list[i+1][j]==list[i][j] && (list[i][j]=='y' or list[i][j]=='r')){
					//	cout << i << " " << j << " " << list[i][j] << " " << list[i][j+1] << endl;
						connect++;
						}
						else {
							if (connect!=0){
								connect = 0;
							}
						}
					if (connect==3){
						if(list[i][j]=='y'){
							cout << "YELLOW wins!" << endl;
						} else cout << "RED wins!" << endl;
						connect = 0;
						win = true;
						break;
					}
				}
			}
			if (win) break;
			connect = 0;
			for(int i=0;i<=6;i++){ //y
				connect = 0;
				for(int j=0;j<=5;j++){
					if (list[i][j]==list[i][j+1] && (list[i][j]=='y' or list[i][j]=='r')){
					//	cout << i << " " << j << " " << list[i][j] << " " << list[i][j+1] << endl;
						connect++;
						}
						else {
							if (connect!=0){
								connect = 0;
							}
						}
					if (connect==3){
						if(list[i][j]=='y'){
							cout << "YELLOW wins!" << endl;
						} else cout << "RED wins!" << endl;
						connect = 0;
						win = true;
						break;
					}
				}
			}
			if (win) break;
			connect = 0;
			//diagonal (left->right) (0,6)->(5,0) (y,x)
			for (int i=6;i>=0;i--){
				connect = 0;
				for (int j=i,k=0;j<=6 && k<=5;j++,k++){
					if (list[k][j]==list[k+1][j+1] && (list[k][j]=='y' or list[k][j]=='r')){
					//	cout << i << " " << j << " " << list[i][j] << " " << list[i][j+1] << endl;
						connect++;
						}
						else {
							if (connect!=0){
								connect = 0;
							}
						}
					if (connect==3){
						if(list[k][j]=='y'){
							cout << "YELLOW wins!" << endl;
						} else cout << "RED wins!" << endl;
						connect = 0;
						win = true;
						break;
					}
				}
			}
			for (int i=1;i<6;i++){
				connect = 0;
				for (int j=0,k=i;j<=6 && k<=5;j++,k++){
					if (list[k][j]==list[k+1][j+1] && (list[k][j]=='y' or list[k][j]=='r')){
					//	cout << i << " " << j << " " << list[i][j] << " " << list[i][j+1] << endl;
						connect++;
						}
						else {
							if (connect!=0){
								connect = 0;
							}
						}
					if (connect==3){
						if(list[k][j]=='y'){
							cout << "YELLOW wins!" << endl;
						} else cout << "RED wins!" << endl;
						connect = 0;
						win = true;
						break;
					}
				}
			}
		if (win) break;
		connect = 0;
		//(right->left) (0,0) -> (5,0) -> (5,6) (y,x) y changes
		for (int i=0;i<6;i++){
				connect = 0;
				for (int j=0,k=i;j<=6 && k>0;j++,k--){
					if (list[k][j]==list[k-1][j+1] && (list[k][j]=='y' or list[k][j]=='r')){
					//	cout << i << " " << j << " " << list[i][j] << " " << list[i][j+1] << endl;
						connect++;
						}
						else {
							if (connect!=0){
								connect = 0;
							}
						}
					if (connect==3){
						if(list[k][j]=='y'){
							cout << "YELLOW wins!" << endl;
						} else cout << "RED wins!" << endl;
						connect = 0;
						win = true;
						break;
					}
				}
			} //(5,1) -> (5,6) (y,x) x changes
			for (int i=1;i<=6;i++){
				connect = 0;
				for (int j=i,k=5;j<=6 && k>0;j++,k--){
					if (list[k][j]==list[k-1][j+1] && (list[k][j]=='y' or list[k][j]=='r')){
					//	cout << i << " " << j << " " << list[i][j] << " " << list[i][j+1] << endl;
						connect++;
						}
						else {
							if (connect!=0){
								connect = 0;
							}
						}
					if (connect==3){
						if(list[k][j]=='y'){
							cout << "YELLOW wins!" << endl;
						} else cout << "RED wins!" << endl;
						connect = 0;
						win = true;
						break;
					}
				}
			}
		}
		if (T>=42){
			cout << "Draw!" << endl;
			for (int k=0;k<5;k++){
							for(int l=0;l<6;l++){
								list[k][l] = ' ';
							}
						}
			T=0;
			break;
		}
	}
}
}

