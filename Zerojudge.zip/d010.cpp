#include <bits/stdc++.h>
using namespace std;

int main(){
	int c;
	while(cin>>c){
		int sum = 0;
		for(int i=1;i<c;i++){
			if (c%i == 0){
				sum += i;	
			}
		}
		if (sum > c){
			cout << "�ռ�" << endl; 
		}
		else if (sum==c){
			cout << "������" << endl;
		}
		else {
			cout << "����" << endl;
		}
	}
}

