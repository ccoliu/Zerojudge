#include <bits/stdc++.h>
using namespace std;

int main(){
	int year;
	cin >> year;
	cout << year-1911 << endl;
}

