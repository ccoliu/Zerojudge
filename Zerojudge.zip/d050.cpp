#include <bits/stdc++.h>
using namespace std;

int main(){
	int time;
	cin >> time;
	cout << abs(time-15+24)%24 << endl;
}

