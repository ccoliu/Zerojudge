#include <bits/stdc++.h>
using namespace std;

int main(){
	float a;
	cin >> a;
	int b = (a/(abs(a)-0.1));
	cout << b << endl;
}

