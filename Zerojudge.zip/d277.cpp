#include <bits/stdc++.h>
using namespace std;

int main(){
	int t;
	while(cin >> t){
	cout << ((t%2==0)?t:t-1) << endl;
	}
}
