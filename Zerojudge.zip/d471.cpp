#include <bits/stdc++.h>
using namespace std;

int main(){
	int n;
	while(cin >> n){
	int t = 0;
	int i = 0;
	bitset<15> x(t);
	for (int j=x.size()-n;j<x.size();j++){
		cout << x[j];
	}
	cout << endl;
	while (i<(pow(2,n))-1){
			t++;
			bitset<15> x(t);
			for (int j=n-1;j>=0;j--){
				cout << x[j];
			}
			cout << endl;
			i++;
	}
}
}

