#include <bits/stdc++.h>
using namespace std;

int main(){
	ios::sync_with_stdio(0);
	cin.tie(0); 
	int j;
	vector<string> p;
	cin >> j;
	for (int i=0;i<=j;i++){
		string s;
		getline(cin,s);
		p.push_back(s); 
	}
	sort(p.begin(),p.end());
	for (int i=0;i<=j;i++){
		cout << p[i] << endl;
	}
}

