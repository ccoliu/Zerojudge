#include <bits/stdc++.h>
using namespace std;

int main(){
	int pen;
	cin >> pen;
	cout << (pen/12)*50 + (pen%12)*5 << endl;
}

