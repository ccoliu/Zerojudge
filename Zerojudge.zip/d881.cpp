#include <bits/stdc++.h>
using namespace std;

int main(){
	int d;
	while(cin >> d){
	unsigned long long pl = 1;
	unsigned long long sum = 0;
	unsigned long long pll = 1;
	for(int i=1;i<=50;i++){
		sum += pll;
		pll += pl; 
		pl = pl + d;
	}
	cout << sum << endl;
}
}

