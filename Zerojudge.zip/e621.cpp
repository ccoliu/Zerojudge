#include <bits/stdc++.h>
#include <vector>
using namespace std;

int main(){
	int c;
	cin >> c;
	int T = 0;
	while (T<c){
		int A,B,C;
		vector<int> slot;
		cin >> A >> B >> C;
		for (int i=A+1;i<B;i++){
			if (i%C){
				slot.push_back(i); 
			}
		}
		if (slot.empty()){
			cout << "No free parking spaces." << endl;
		}
		else {
			for (int i=0;i<slot.size();i++){
				cout << slot[i] << " ";			
			}
			cout << endl;
		}
		T++;
	}
}

