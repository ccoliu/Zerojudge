#include <bits/stdc++.h>
using namespace std;

int main(){
	int c;
	int section = 0;
	int row = 1;
	int seat = 0;
	int g = 0;
	cin >> c;
	if (c <= 2500){
		section = 1;
	}
	else if (c > 2500 && c <= 7500){
		section = 2;
	}
	else {
		section = 3;
	}
	if (section == 2){
		c -= 2500;
		g = c/50;
		row += g;
		c -= 50*g;
		seat = c;
		if (seat==0){
			row -= 1;
			seat = 50;
		}
	}
	else if (section == 3){
		c -= 7500;
		g = c/25;
		row += g;
		c -= 25*g;
		seat = c;
		if (seat==0){
			row -= 1;
			seat = 25;
		}
	}
	else {
		g = c/25;
		row += g;
		c -= 25*g;
		seat = c;
		if (seat==0){
			row -= 1;
			seat = 25;
		}
	}
	cout << section << " " << row << " " << seat << endl;
}

