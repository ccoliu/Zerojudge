#include <stdio.h>

int main ()
{
  char buffer [50];
  int n, a=5, b=3;
  n=sprintf (buffer, "123", a, b, a+b);
  printf ("%s %d",buffer,n);
  return 0;
}

