#include <bits/stdc++.h>
#define fastio cin.tie(0),ios::sync_with_stdio(0)
using namespace std;

struct solider {
	string name;
	int group,stage;
};



int main(){
//	fastio;
//	int n,m;
//	solider x[n];
//	map<solider,int> mmap;
//	for (int i=0;i<m;i++){
//		cin >> x[i].name >> x[i].group >> x[i].stage;
////		map<solider,int>::iterator it = mmap.find(x[i]);
////		if (it==mmap.end()){
////			mmap.insert(make_pair(x[i],1));
////		}
//	}
	cout << "�I" << endl;
	 
}

