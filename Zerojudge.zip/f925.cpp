#include <bits/stdc++.h>
using namespace std;
int main(){int m,d;cin >> m >> d;cout << ((m==6&&d==12)?"Yes":"No") << endl;}

