#include <bits/stdc++.h>
using namespace std;

int main(){
	int n;
	cin >> n;
	cout << "2^(10^" << n << ")" << endl;
}

