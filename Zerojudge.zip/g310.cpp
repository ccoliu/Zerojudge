#include <bits/stdc++.h>
using namespace std;

int main(){
	int n;
	cin >> n;
	int x[n] = {0};
}

