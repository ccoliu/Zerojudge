#include <bits/stdc++.h>
using namespace std;

int main(){
	int c;
	cin >> c;
	int T = 0;
	while (T<c){
		int x[1000] = {0};
		int o[1000] = {0};
		bool n[1000] = {0};
		bool failed = false;
		int sum = 0;
		string samp,s;
		cin >> samp >> s;
		for (int i=0;i<samp.length();i++){
			x[samp[i]]++;
			o[samp[i]]++;
		}
		for (int i=0;i<s.length();i++){
			x[s[i]]--;
			n[s[i]] = 1;
			if (o[s[i]]==0){
				failed = true;	
			}
		}
		for (int i=0;i<1000;i++){
			sum += abs(x[i]);
			if(n[i] == 0 && o[i]>0 || x[i] > 0){
				failed = true;
			}
		}
		if (failed==true){
			cout << "Case #" << T+1 << ": IMPOSSIBLE" << "\n";
		}
		else {
			cout << "Case #" << T+1 << ": " << sum << "\n";
		}
		T++;
	}
}

