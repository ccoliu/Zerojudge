#include <bits/stdc++.h>
using namespace std;

int main(){
	int lines,legs;
	cin >> lines >> legs;
	int leg[legs] = {0};
	for (int i=0;i<legs;i++){
		cin >> leg[i];
	}
	int pos;
	cin >> pos;
	for (int i=0;i<legs;i++){
		if (pos==leg[i]){
			pos++;
		}
		else if (pos-1==leg[i]){
			pos--;
		}
	}
	cout << pos << endl;
}

