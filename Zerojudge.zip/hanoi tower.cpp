#include <bits/stdc++.h>
using namespace std;

int main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
	int a,b,c,d;
	char n;
	while(cin >> a >> b >> c >> d >> n){
	int gcd = 1;
	if (b<0){
			a = -a;
			b = -b;
		}
		else if (d<0){
			c = -c;
			d = -d;
	}
	if(n=='+'){
		int b1 = abs(b);
		int d1 = abs(d);
		int min,max;
		if (b!=d){
		max = (b1>d1)?b1:d1;
		min = (b1<d1)?b1:d1;
		while (max%min!=0){
			gcd = max % min;
			max = min;
			min = gcd;
		}
		gcd = abs(b*d/gcd);
		a*= gcd/b; c*=gcd/d; b=gcd; a+=c;
		}
		else a+=c;
		b1 = abs(a);
		d1 = abs(b);
		while (b1!=0 and d1!=0){
			(b1>=d1) ? b1 = b1%d1 : d1 = d1%b1;
		}
		(b1>=d1) ? gcd = b1 : gcd = d1;
		a /= gcd; b /= gcd; 
	}
	else if (n=='-'){
		int b1 = abs(b);
		int d1 = abs(d);
		int min,max;
		if (b!=d){
		max = (b1>d1)?b1:d1;
		min = (b1<d1)?b1:d1;
		while (max%min!=0){
			gcd = max % min;
			max = min;
			min = gcd;
		}
		gcd = abs(b*d/gcd); 
		a*= gcd/b; c*=gcd/d; b=gcd; a-=c;
		}
		else a-=c;
		b1 = abs(a);
		d1 = abs(b);
		while (b1!=0 and d1!=0){
			(b1>=d1) ? b1 = b1%d1 : d1 = d1%b1;
		}
		(b1>=d1) ? gcd = b1 : gcd = d1;
		a /= gcd; b /= gcd; 
	}
	else if (n=='*'){
		a *= c; b*= d;
		int b1 = abs(a);
		int d1 = abs(b);
		while (b1!=0 and d1!=0){
			(b1>=d1) ? b1 = b1%d1 : d1 = d1%b1;
		}
		(b1>=d1) ? gcd = b1 : gcd = d1;
		a /= gcd; b /= gcd;
	}
	else if (n=='/'){
		a *= d; b*=c;
		int b1 = abs(a);
		int d1 = abs(b);
		while (b1!=0 and d1!=0){
			(b1>=d1) ? b1 = b1%d1 : d1 = d1%b1;
		}
		(b1>=d1) ? gcd = b1 : gcd = d1;
		a /= gcd; b /= gcd;
	}
	if (b < 0){
		a = -a;
		b = -b;
	}
	if (b==1 or a==0){
		cout << a << endl;
	}
	else 
		cout << a << "/" << b << endl;
	}
}
