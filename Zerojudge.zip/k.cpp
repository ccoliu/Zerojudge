#include <bits/stdc++.h>
using namespace std;
#define f(i,k,l) for(int i=k;i<l;i++)


int main(){
	int a;
	cin >> a;
	char b[a][a];
	int circle,cross;
	int cir,cr;
	cir = 0;
	cr = 0;
	char c[a*a];
	int streak;
	int d = 0;
	int v = 0;
	f(i,0,a){
		f(j,0,a){
			cin >> b[i][j];
		}
	}
	f(k,0,a){
		f(l,0,a){
			if(b[k][l]=='O'){
				cir++;
			}
			else{
				cr++;
			}	
		}
	}
	if(cir-cr<=1&&cir-cr>=-1){
		circle = 0;
		cross = 0;
		f(n,0,a){
			f(o,0,a){
				c[d] = b[n][o];
				d++;
			}
		}
		f(m,0,a*a-1){
			if (c[m]==c[m+1]){
			streak++;
			}
			v++;
			if(v==a){
				streak = 0;
				v = 0;
			}
			cout << streak << endl;
			if(streak==a-1){
				if(c[m]=='O'){
						circle++;
				}
				else{
						cross++;
					}
					streak = 0;
				}
		}
		streak = 0;
		for(int p=0;p<a;p++){		//0,5,10,15
			if(c[(a+1)*p]==c[(a+1)*(p+1)]){
				streak++;
			}
		}
		cout << streak << endl;
		if(streak==a-1){
				if(c[0]=='O'){		
						circle++;
					}
				else{
						cross++;
					}
			streak = 0;
		}
		streak = 0;
		for(int q=1;q<a;q++){		//3,6,9,12
			if(c[(a-1)*q]==c[(a-1)*(q+1)]){
				streak++;
			}
		}
		cout << streak << endl;
		if(streak==a-1){
					if(c[a-1]=='O'){
						circle++;
					}
				else{
						cross++;
					}
			streak = 0;
		}
		cout << circle << " " << cross << endl;
	}
	else {
		cout << "impossible" << endl;
	}
}
