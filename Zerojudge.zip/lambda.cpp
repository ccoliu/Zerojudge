#include <bits/stdc++.h>
using namespace std;
int m = 5;
int main(){
	int n = 10;
	auto i = []() mutable {
		n = 20;
		cout << n << endl;
	};
	i();
	cout << m << endl << n;
}

