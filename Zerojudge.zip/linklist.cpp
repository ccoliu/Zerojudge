#include <stdio.h>
using namespace std;

struct node {
	int value;
	node *next;
};

int main(){
	int n;
	scanf("%d",&n);
	int g;
	node *head = new node();
	scanf("%d",&g);
	head->value = g;
	head->next = NULL;
	node *current = head;	
	for (int i=1;i<n;i++){
		current->next = new node();
		int v;
		scanf("%d",&v);
		current = current->next;
		current->value = v;
		current->next = NULL;
	}
	node *f = head;
	while(true){
		printf("path: %p\n",f);
		printf("value: %d\n",f->value);
		printf("next path: %p\n",f->next);
		f = f->next;
		if (f==NULL){
			break;
		} 
	}
}

