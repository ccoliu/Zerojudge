#include <bits/stdc++.h>
using namespace std;

int visit (int,int);

int maze[7][7]=	{{2, 2, 2, 2, 2, 2, 2}, 
                  {2, 0, 0, 0, 0, 0, 2}, 
                  {2, 0, 2, 0, 2, 0, 2}, 
                  {2, 0, 0, 2, 0, 2, 2}, 
                  {2, 2, 0, 2, 0, 2, 2}, 
                  {2, 0, 0, 0, 0, 0, 2}, 
                  {2, 2, 2, 2, 2, 2, 2}}; 
                  
int startx = 1, starty = 1;
int endx = 5, endy = 5;
int success = 0;
                  
int main(){
	for (int i=0;i<7;i++){
		for (int j=0;j<7;j++){
			if (maze[i][j]==2){
				cout << "| ";
			}
			else {
				cout << "  ";
			}
		}
		cout << endl;
	}
	if (visit(startx, starty)==0){
		cout << "�S�����X�f!" << endl; 
	}
	else {
		cout << "��ܸ��|" << endl;
		for (int i=0;i<7;i++){
		for (int j=0;j<7;j++){
			if (maze[i][j]==2){
				cout << "| ";
			}
			else if (maze[i][j]==1){
				cout << ". ";
			}
			else {
				cout << "  ";
			}
		}
		cout << endl;
	}
	}
}

int visit(int i,int j){
	maze[i][j] = 1;
	if (i == endx && j == endy){
		success = 1;
	}
	if (success!=1){
		if (maze[i][j+1] == '.'){
			visit(i,j+1);
		}
		if (maze[i+1][j]== '.'){
			visit(i+1,j);
		}
		if (maze[i][j-1]== '.'){
			visit(i,j-1);
		}
		if (maze[i-1][j]== '.') {
			visit(i-1,j);
		}
	}
	if (success != 1){
		maze[i][j] = 0;
	}
	return success;
}

