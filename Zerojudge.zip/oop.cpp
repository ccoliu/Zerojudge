#include <bits/stdc++.h>
using namespace std;

int main(){
	double n,guess;
	cin >> n;
	guess = n/2;
	double r = n/guess;
	double newguess = (guess+r)/2;
	while (guess-newguess > 0.01){
		guess = newguess;
		r = n/guess;
		newguess = (guess+r)/2;
	}
	cout << fixed << setprecision(2) << newguess << endl;
}

