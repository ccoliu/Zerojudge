#include <bits/stdc++.h>
using namespace std;

int main(){
	long long A;
	while(cin >> A){
		long long hours = A/3600;
		A = A%3600;
		long long minutes = A/60;
		A = A%60;
		cout << hours << " " << minutes << " " << A << endl; 
	}
}

