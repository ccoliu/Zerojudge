#include <bits/stdc++.h>
#define fastio cin.tie(0),ios::sync_with_stdio(false)
using namespace std;

int main(){
	fastio;
	int c;
	while(cin >> c){
		int x[c][c] = {0};
		int o = 1;
		for (int i=1;i<=c;i++){
			if (i%2==1){
				for(int j=(i-1)*c+1;j<=(i*c);j++){
					if (j!=(i*c)){
						cout << j << " ";
					} else cout << j;
				}
			} else {
				for(int j=i*c;j>=(i-1)*c+1;j--){
					if (j!=(i-1)*c+1){
						cout << j << " ";
					} else cout << j;	
				}
			}
			cout << endl;
		}
		cout << endl;
	}
}

