#include <stdio.h>
#include <stdlib.h>

int main(){
	int* a;
	int b = 100;
	a = &b;
	printf("%d",*a);
} 
