#include <bits/stdc++.h>
#include <vector>
using namespace std;

int main(){
	int a,b,c;
	while (cin >> a >> b >> c){
	queue<int> s;
	int p;
	int k;
	int n;
	int i = 1;
	p = floor(a/b);
	k = a % b;
	if (k==0){
		while(i<=c){
			s.push(0);
			i++; 
		}
	}
	else {
		while(i<=c){
			k = k * 10;
			n = floor(k/b);
			s.push(n);
			k = k % b;
			i++;
		}
	}
	cout << p << ".";
	while(s.size()!=0){
		cout << s.front();
		s.pop();
	}
	cout << endl;
}
}
