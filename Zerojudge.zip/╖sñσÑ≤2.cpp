#include <bits/stdc++.h>
using namespace std;

int main(){
	int b;
	int c,d;
	cin >> b;
	for(int i=1;i<=b;i++){
		cin >> c >> d;
		int t[c][c] = {0};
		int r = 1;
		int row,column = 0;
		if (d==1){
			while(r<=(c*c)){
				t[row][column] = r;
				if(column==c-1||t[row][column+1]!=0){
					
				}
				else{
					column++;
				}
				r++;
			} 
		}
	}
}
