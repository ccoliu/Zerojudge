#include <bits/stdc++.h>
using namespace std;
#include <string>


int main(){
	int n;
	cin.tie(0);
	cin >> n;
	string T[n*n];
	int ans = 0;
	int a = 1;
	for (int i=0;i<n;i++){
		T[ans] += "("; 
	}
	for (int i=0;i<n;i++){
		T[ans] += ")";
	} //�Ĥ@��
	cout << T[ans] << endl;
	while (a<=ceil(n/2)+1){
		int set = n-a; //1
		char temp;
		while (set<n*2-2){ //4 < 6
			ans++;
			T[ans] = T[ans-1];
			set++;
			temp = T[ans][set];
			T[ans][set] = T[ans][set-1];
			T[ans][set-1] = temp;
			cout << T[ans] << "\n";
		}
		cout << "ok" << "\n";
		a++;
	} 
}
