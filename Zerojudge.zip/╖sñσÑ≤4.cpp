#include <stdlib.h>
#include <iostream>

using namespace std;

int main() {
    int T, M, N;
    int R[100][100];   // ���G
    cin >> T;   // ����ƶq
    for (int i=0; i<T; i++) {
        int n = 1;   // �p�ƾ� (¶�h��)
        cin >> N >> M;   // �j�p, ��V
        for (int j=0; j<(N+1)/2; j++) {   // �ĴX�h
            for (int k=0; k<N-2*j-1; k++)   // �W��
                R[j][j+k] = n++;
            for (int k=0; k<N-2*j-1; k++)   // �k��
                R[j+k][N-j-1] = n++;
            for (int k=0; k<N-2*j-1; k++)   // �U��
                R[N-j-1][N-k-j-1] = n++;
            for (int k=0; k<N-2*j-1; k++)   // ����
                R[N-j-k-1][j] = n++;
        }
        if (N%2)   // �_�Ƥj�p
            R[N/2][N/2] = n;   // ������

        for (int j=0; j<N; j++) {   // row
            for (int k=0; k<N; k++)   // col
                if (M == 1)   // ���ɰw
                    printf("%5d", R[j][k]);
                else   // �f�ɰw
                    printf("%5d", R[k][j]);   // ��C�洫
            printf("\n");
        }
        printf("\n");
    }
    return 0;
}
