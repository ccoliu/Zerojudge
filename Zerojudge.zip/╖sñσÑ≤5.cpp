#include <bits/stdc++.h>
using namespace std;

int main(){
	int B;
	cin >> B;
	for(int i=0;i<B;i++){
		int c,D;
		cin >> c >> D;
		int T[100][100] = {};
		int u = 0;
		int l = 0;
		int r = c - 1;
		int d = c - 1;
		int t = 1;
		while(t<(c*c)){
			for (int A=l;A<=r;A++){
				T[u][A] = t++;
			}
			u++;
			for (int B=u;B<=d;B++){
				T[B][r] = t++;
			}
			r--;
			for (int C=r;C>=l;C=C-1){
				T[d][C] = t++;
			}
			d--;
			for (int E=d;E>=u;E=E-1){
				T[E][l] = t++; 
			}
			l++;
		}
		if (c%2==1){
			T[c/2][c/2] = t; // 1,1
		}
		if (D==1){
		for (int o=0;o<c;o++){
			for(int p=0;p<c;p++){
				cout << setw(5) << T[o][p];
			}
			cout << endl;
		}
		}
	else {
		for (int o=0;o<c;o++){
			for(int p=0;p<c;p++){
				cout << setw(5) << T[p][o];
			}
			cout << endl;
		}
		}
	}
} 
