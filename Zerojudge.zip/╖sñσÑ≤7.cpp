#include <bits/stdc++.h>
#include <vector>
using namespace std;

float sum = 0;
int recursive(int n){
	if (n == 1){
		sum += 1;
	}
	else if (n%2==0){
		sum += 1;
		recursive(n/2);
	}
	else{
		sum = pow(recursive(n-1),-1);
	}
	return sum;
}

int main(){
	cin.tie(0);
	ios::sync_with_stdio(false);
	int a,b;
	int n;
	while (cin >> n){
		recursive(n);
		cout << fixed << setprecision(5) << sum << endl;
		sum = 0;
	}
} 
