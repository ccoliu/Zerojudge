#include <bits/stdc++.h>
#include <string>
using namespace std;

int main(){
	string s;
	while(getline(cin,s)){
	int ans = 0;
	if (isalpha(s[0])){
	ans = 1;
	for (int i=0;i<s.length()-1;i++){
		if (!isalpha(s[i])&&isalpha(s[i+1])){
			s[i] = '1';
		}
	}
	for (int i=0;i<s.length();i++){
		if (s[i]=='1'){
			ans++;
		}
	}
	cout << ans << endl;
	}
	else cout << ans << endl;
} 
}
